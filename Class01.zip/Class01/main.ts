let name1 = ("thsi is testing only")

console.warn (name1);