var name1 = ("thsi is testing only");
console.log(name1);
